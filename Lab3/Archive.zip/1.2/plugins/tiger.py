class Tiger:
    def __init__(self, name):
        self.name = name
    
    def greet(self):
        print("Ljubimac {} pozdravlja: Sto mu gromova!".format(self.name))
    
    def menu(self):
        print("Ljubimac {} voli brazilske orahe.".format(self.name))