package hr.fer.ooup.lab3.editor.observer.cursor;

import hr.fer.ooup.lab3.editor.Location;

public interface CursorObserver {

	public void updateCursorLocation(Location loc);
}
