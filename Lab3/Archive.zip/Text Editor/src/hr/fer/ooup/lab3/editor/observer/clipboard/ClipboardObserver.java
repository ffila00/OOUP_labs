package hr.fer.ooup.lab3.editor.observer.clipboard;

public interface ClipboardObserver {

	public void updateClipboard();
}
