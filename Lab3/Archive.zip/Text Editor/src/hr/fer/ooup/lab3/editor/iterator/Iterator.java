package hr.fer.ooup.lab3.editor.iterator;

public interface Iterator<T> {

	public boolean hasNext();
	public T next();
}
