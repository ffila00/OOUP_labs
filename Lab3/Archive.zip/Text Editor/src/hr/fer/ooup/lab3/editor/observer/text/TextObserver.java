package hr.fer.ooup.lab3.editor.observer.text;

public interface TextObserver {
	
	public void updateText();
}
